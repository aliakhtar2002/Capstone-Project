#!/bin/bash
# CyberPulse Automated Backup System

BACKUP_DIR="/home/ec2-user/backups"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

echo "Starting CyberPulse backup..."
mkdir -p $BACKUP_DIR

tar -czf $BACKUP_DIR/cyberpulse_full_$TIMESTAMP.tar.gz \
    /home/ec2-user/api/ \
    /home/ec2-user/cyberpulse_deliverables/

echo "Backup completed: $BACKUP_DIR/cyberpulse_full_$TIMESTAMP.tar.gz"
