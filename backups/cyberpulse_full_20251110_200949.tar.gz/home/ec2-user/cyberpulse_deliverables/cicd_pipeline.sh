#!/bin/bash
echo "🚀 CyberPulse CI/CD Pipeline"
echo "1. Security scanning..."
bandit -r ./api/
echo "2. Running tests..." 
python3 test_api.py
echo "✅ Pipeline completed"
