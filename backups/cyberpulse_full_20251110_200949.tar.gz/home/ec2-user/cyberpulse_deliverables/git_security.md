# Git Security Implementation

## Security Hooks Installed:
- pre-commit: Bandit security scanning
- Blocks commits with security issues

## VS Code Extensions Configured:
- Python Bandit extension
- GitLens for commit security
- YAML linting for configurations

## Usage:
git add .
git commit -m "message" # Triggers security scan
