# simulate_powershell_like.py
# Usage: python3 simulate_powershell_like.py
# Creates suspicious PowerShell-like command lines in syslog (or local messages_simulated.log)
import subprocess, shutil, time, os
def main():
    msgs = [
        "Invoke-Expression IEX -EncodedCommand SGVsbG8gV29ybGQ=",
        "Suspicious command: -EncodedCommand"
    ]
    logger_path = shutil.which("logger")
    if logger_path:
        for m in msgs:
            try:
                subprocess.run([logger_path, "-p", "user.notice", m], check=True)
            except Exception:
                logger_path = None
                break
            time.sleep(0.1)
    if not logger_path:
        script_dir = os.path.dirname(__file__)
        out = os.path.join(script_dir, "messages_simulated.log")
        with open(out, "a") as f:
            for line in msgs:
                f.write(line + "\n")
        print("Logger not available or failed — wrote powershell-like simulation to", out)
    else:
        print("PowerShell-like simulation sent via system logger.")
if __name__ == '__main__':
    main()
