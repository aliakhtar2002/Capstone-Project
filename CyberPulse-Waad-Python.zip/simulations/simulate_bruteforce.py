# simulate_bruteforce.py
# Usage: python3 simulate_bruteforce.py
# Sends multiple failed SSH auth messages. If 'logger' binary is present and usable,
# it will call logger to write to system syslog. Otherwise it will append lines to
# ./secure_simulated.log inside the script directory.
import subprocess, shutil, time, os
def main():
    msg_template = "Failed password for invalid user testuser from 203.0.113.55 port {port} ssh2"
    logger_path = shutil.which("logger")
    entries = []
    for i in range(1,13):
        port = 2200 + i
        msg = msg_template.format(port=port)
        entries.append(msg)
        if logger_path:
            try:
                subprocess.run([logger_path, "-p", "authpriv.notice", msg], check=True)
            except Exception as e:
                # fallback to local file if logger fails
                logger_path = None
        time.sleep(0.1)
    if not logger_path:
        # write to local simulated secure log
        script_dir = os.path.dirname(__file__)
        out = os.path.join(script_dir, "secure_simulated.log")
        with open(out, "a") as f:
            for line in entries:
                f.write(line + "\n")
        print("Logger not available or failed — wrote simulation to", out)
    else:
        print("Brute force simulation sent via system logger.")
if __name__ == '__main__':
    main()
