# simulate_sudo.py
# Usage: python3 simulate_sudo.py
# Simulates sudo authentication failure and a root session opened message.
import subprocess, shutil, time, os
def main():
    msgs = [
        "sudo: pam_unix(sudo:auth): authentication failure; logname= uid=1000 euid=0 tty=/dev/pts/0 ruser= rhost=203.0.113.55",
        "session opened for user root by (uid=0)"
    ]
    logger_path = shutil.which("logger")
    if logger_path:
        for m in msgs:
            try:
                subprocess.run([logger_path, "-p", "authpriv.notice", m], check=True)
            except Exception:
                logger_path = None
                break
            time.sleep(0.2)
    if not logger_path:
        script_dir = os.path.dirname(__file__)
        out = os.path.join(script_dir, "secure_simulated.log")
        with open(out, "a") as f:
            for line in msgs:
                f.write(line + "\n")
        print("Logger not available or failed — wrote sudo simulation to", out)
    else:
        print("Sudo simulation sent via system logger.")
if __name__ == '__main__':
    main()
