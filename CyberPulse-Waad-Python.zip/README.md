CyberPulse - Waad (Python-based artifacts)
==========================================
What this package contains:
- /simulations/: Python scripts to simulate suspicious events.
  * simulate_bruteforce.py
  * simulate_sudo.py
  * simulate_powershell_like.py
- /splunk_rules/: SPL queries you can paste into Splunk Search & Reporting.
- /screenshots/: empty folder where you or teammates can save terminal tails or screenshots.
- README.md (this file).

Important usage notes (copy & paste to send to a teammate if you don't have EC2 access):
-------------------------------------------------------------------------------
1) If you have direct SSH access to the EC2 instance, upload this package there and run:
   python3 simulations/simulate_bruteforce.py
   python3 simulations/simulate_sudo.py
   python3 simulations/simulate_powershell_like.py

   Each script will try to call the system 'logger' binary to append to the OS syslog.
   If 'logger' isn't available or the script lacks permissions, it will write local
   files in the simulations/ folder (secure_simulated.log or messages_simulated.log).

2) If you DO NOT have SSH access, send this package to a teammate and ask them to:
   - unzip
   - run the three python scripts on the EC2 instance as above
   - after running, run:
     tail -n 30 /var/log/secure
     tail -n 30 /var/log/messages
     and take screenshots or save the output to files in the /screenshots/ folder.
   - then paste the SPL queries from /splunk_rules/ into Splunk and verify results.

3) To reproduce or inspect without syslog access:
   - Run the python scripts locally; they will create local 'secure_simulated.log' and
     'messages_simulated.log' inside the simulations/ folder when system logging is not writable.

If you want, I can also generate importable Splunk saved-search JSON files — tell me and I'll add them.
